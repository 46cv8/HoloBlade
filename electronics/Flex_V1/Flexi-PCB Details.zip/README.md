All PCB files and intermediate files used in ordering the FFC Cable

Ordered from Elecrow.com Premium PCB service: https://www.elecrow.com/premium-pcb-service-p-1061.html

If they haven't changed their procedure, you will need to send the Gerber files (in flex_v1.zip),
PCB requirements (flex_pcb_requirements.xlsx) and the image showing location of stiffeners
(stiffner.png) to service@elecrow.com for a quote.

Leave most of the parameter in the requirements file as is, length, quantity and shipping address should be changed. May be worth testing with 0.5oz
copper as that may be much cheaper but have not tested this.